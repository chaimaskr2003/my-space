// AI Assistant edge function for MySpace
// Redeployed to sync verify_jwt config
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

type Action =
  | "summarize_note"
  | "organize_summary"
  | "generate_mindmap"
  | "organize_tasks"
  | "organize_challenge";

const promptTemplates: Record<Action, (content: string, context?: string) => string> = {
  summarize_note: (c) =>
    `Summarize the following note concisely in the same language as the note. Keep key points:\n\n${c}`,
  organize_summary: (c) =>
    `Organize the following text into clear headings and bullet points. Use markdown-style formatting with "# " for headings and "- " for bullets. Keep the same language as the original text:\n\n${c}`,
  generate_mindmap: (c) =>
    `Create a mind map structure from the following text. Return ONLY valid JSON in this exact format (no markdown, no code fences): {"id":"root","text":"Central Topic","children":[{"id":"b1","text":"Branch 1","children":[{"id":"s1","text":"Sub-branch","children":[]}]}]}. Use the same language as the original text:\n\n${c}`,
  organize_tasks: (c) =>
    `Organize the following tasks by priority (high, normal, low). Return as a simple list grouped under "## High Priority", "## Normal Priority", "## Low Priority". Keep the same language as the tasks:\n\n${c}`,
  organize_challenge: (c) =>
    `Help organize this personal challenge. Suggest a clear structure and milestones. Keep the same language as the input:\n\n${c}`,
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { action, content, context } = (await req.json()) as {
      action: Action;
      content: string;
      context?: string;
    };

    if (!action || !content) {
      return new Response(
        JSON.stringify({ error: "Missing action or content" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("OPENAI_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "AI service not configured. API key missing." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const prompt = promptTemplates[action](content, context);

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "You are a helpful assistant inside a personal organization app. Follow the user's instructions precisely. Respond in the same language as the user's content.",
          },
          { role: "user", content: prompt },
        ],
        max_tokens: 1200,
        temperature: 0.5,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return new Response(
        JSON.stringify({ error: `AI service error: ${response.status} ${errText}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const result = data.choices?.[0]?.message?.content;

    if (!result) {
      return new Response(
        JSON.stringify({ error: "Empty response from AI" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ result: result.trim() }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return new Response(
      JSON.stringify({ error: msg }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
