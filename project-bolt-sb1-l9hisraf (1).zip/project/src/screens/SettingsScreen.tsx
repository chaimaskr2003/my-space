import { Sun, Moon, Globe, LogOut, User, Shield } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useAuth } from '@/context/AuthContext';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Label } from '@/components/ui/Input';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { TranslationKey } from '@/lib/i18n';

export function SettingsScreen() {
  const { t, theme, setTheme, language, setLanguage } = useApp();
  const { profile, signOut, refreshProfile } = useAuth();
  const [name, setName] = useState(profile?.display_name ?? '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSaveName = async () => {
    setSaving(true);
    await supabase.from('profiles').upsert({
      id: profile?.id,
      display_name: name.trim() || null,
    });
    await refreshProfile();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">{t('settings')}</h1>
      </div>

      <Card className="p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 text-white flex items-center justify-center font-semibold text-lg">
            {name?.[0]?.toUpperCase() || <User size={22} />}
          </div>
          <div>
            <p className="font-semibold text-gray-900 dark:text-gray-100">
              {name || t('profile')}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {profile?.id ? '' : ''}
            </p>
          </div>
        </div>
        <div>
          <Label>{t('name')}</Label>
          <div className="flex gap-2">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t('name')} />
            <Button onClick={handleSaveName} disabled={saving} className="flex-shrink-0">
              {saved ? '✓' : t('save')}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-5 space-y-4">
        <div>
          <Label>{t('lightMode')} / {t('darkMode')}</Label>
          <div className="flex gap-2">
            <button
              onClick={() => setTheme('light')}
              className={`flex-1 h-11 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all ${
                theme === 'light'
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
              }`}
            >
              <Sun size={18} />
              {t('lightMode')}
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`flex-1 h-11 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all ${
                theme === 'dark'
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
              }`}
            >
              <Moon size={18} />
              {t('darkMode')}
            </button>
          </div>
        </div>

        <div>
          <Label>{t('language')}</Label>
          <div className="flex gap-2">
            <button
              onClick={() => setLanguage('ar')}
              className={`flex-1 h-11 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all ${
                language === 'ar'
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
              }`}
            >
              <Globe size={18} />
              {t('arabic')}
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`flex-1 h-11 rounded-xl flex items-center justify-center gap-2 text-sm font-medium transition-all ${
                language === 'en'
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
              }`}
            >
              <Globe size={18} />
              {t('english')}
            </button>
          </div>
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-start gap-3 text-sm text-gray-600 dark:text-gray-400">
          <Shield size={20} className="flex-shrink-0 mt-0.5 text-gray-400" />
          <div>
            <p className="font-medium text-gray-800 dark:text-gray-200 mb-1">
              {t('appName')}
            </p>
            <p className="text-xs leading-relaxed">
              {language === 'ar'
                ? 'تطبيق خاص لتنظيمك الشخصي. بياناتك محمية ولا يمكن لأي مستخدم آخر الوصول إليها.'
                : 'A private app for your personal organization. Your data is protected and no other user can access it.'}
            </p>
          </div>
        </div>
      </Card>

      <Button variant="danger" onClick={signOut} className="w-full gap-2">
        <LogOut size={18} />
        {t('signOut')}
      </Button>
    </div>
  );
}
