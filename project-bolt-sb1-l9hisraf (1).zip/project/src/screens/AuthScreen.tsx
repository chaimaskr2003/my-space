import { useState, type FormEvent } from 'react';
import { Loader2, Mail, Lock, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/Button';
import { Input, Label } from '@/components/ui/Input';

export function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const { t, language, setLanguage } = useApp();
  const [mode, setMode] = useState<'signin' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (mode === 'signup' && password !== confirmPassword) {
      setError(language === 'ar' ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError(language === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' : 'Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    const { error } =
      mode === 'signin'
        ? await signIn(email, password)
        : await signUp(email, password, name || email.split('@')[0]);
    setLoading(false);

    if (error) {
      setError(error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-purple-50 via-pink-50 to-white dark:from-gray-900 dark:to-gray-950">
      <div className="flex justify-end p-4">
        <button
          onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
          className="text-sm font-medium text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors px-3 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          {language === 'ar' ? 'English' : 'العربية'}
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-20">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8 flex flex-col items-center">
            <div className="flex justify-center mb-4">
              <img 
                src="/logo.png" 
                alt="MySpace Logo" 
                className="w-20 h-20 rounded-2xl object-cover shadow-lg shadow-purple-600/30 border border-white/20" 
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('appName')}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{t('tagline')}</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700/50 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
              {mode === 'signin' ? t('welcomeBack') : t('createYourAccount')}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-5">
              {mode === 'signin'
                ? t('signIn')
                : t('signUp')}
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <div>
                  <Label>{t('name')}</Label>
                  <div className="relative">
                    <User size={18} className="absolute top-3.5 start-3.5 text-gray-400" />
                    <Input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={t('name')}
                      className="ps-11"
                      required
                    />
                  </div>
                </div>
              )}

              <div>
                <Label>{t('email')}</Label>
                <div className="relative">
                  <Mail size={18} className="absolute top-3.5 start-3.5 text-gray-400" />
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="ps-11"
                    required
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <Label>{t('password')}</Label>
                <div className="relative">
                  <Lock size={18} className="absolute top-3.5 start-3.5 text-gray-400" />
                  <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="ps-11"
                    required
                    dir="ltr"
                  />
                </div>
              </div>

              {mode === 'signup' && (
                <div>
                  <Label>{t('confirmPassword')}</Label>
                  <div className="relative">
                    <Lock size={18} className="absolute top-3.5 start-3.5 text-gray-400" />
                    <Input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="ps-11"
                      required
                      dir="ltr"
                    />
                  </div>
                </div>
              )}

              {error && (
                <div className="text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg px-3 py-2">
                  {error}
                </div>
              )}

              <Button type="submit" size="lg" className="w-full" disabled={loading}>
                {loading ? (
                  <Loader2 size={20} className="animate-spin" />
                ) : mode === 'signin' ? (
                  t('signIn')
                ) : (
                  t('createAccount')
                )}
              </Button>
            </form>

            <div className="mt-5 text-center">
              <button
                onClick={() => {
                  setMode(mode === 'signin' ? 'signup' : 'signin');
                  setError(null);
                }}
                className="text-sm text-purple-600 dark:text-purple-400 hover:underline font-medium"
              >
                {mode === 'signin' ? t('noAccount') : t('haveAccount')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}