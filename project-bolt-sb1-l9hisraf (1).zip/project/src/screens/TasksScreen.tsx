import { useState } from 'react';
import { Plus, CheckSquare, Trash2, Edit3, Check, Bell, Clock, ChevronLeft } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useTasks } from '@/hooks/useData';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Label, Textarea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { EmptyState } from '@/components/ui/EmptyState';
import { ConfirmDialog, AiAssistant } from '@/components/AiAssistant';
import { formatShortDate, todayISODate } from '@/lib/utils';
import type { Task } from '@/types/database';
import type { TranslationKey } from '@/lib/i18n';

type Filter = 'today' | 'upcoming' | 'completed';

export function TasksScreen() {
  const { t, language } = useApp();
  const { tasks, loading, create, update, remove, toggleComplete } = useTasks();
  const [filter, setFilter] = useState<Filter>('today');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Task | null>(null);
  const [showAi, setShowAi] = useState(false);

  const today = todayISODate();

  const filtered = tasks.filter((task) => {
    if (filter === 'today') return task.task_date === today && !task.completed;
    if (filter === 'upcoming')
      return task.task_date && task.task_date > today && !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const filters: { id: Filter; labelKey: TranslationKey; count: number }[] = [
    { id: 'today', labelKey: 'today', count: tasks.filter((tk) => tk.task_date === today && !tk.completed).length },
    { id: 'upcoming', labelKey: 'upcoming', count: tasks.filter((tk) => tk.task_date && tk.task_date > today && !tk.completed).length },
    { id: 'completed', labelKey: 'completed', count: tasks.filter((tk) => tk.completed).length },
  ];

  const handleCreate = () => {
    setEditing(null);
    setShowForm(true);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">{t('tasks')}</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            {filtered.length} {t('tasks').toLowerCase()}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => setShowAi(!showAi)}>
            <span className="text-purple-500 text-lg">✦</span>
          </Button>
          <Button size="sm" onClick={handleCreate} className="gap-1.5">
            <Plus size={18} />
            {t('newTask')}
          </Button>
        </div>
      </div>

      {showAi && (
        <Card className="p-3">
          <AiAssistant
            action="organize_tasks"
            content={tasks.map((tk) => `- ${tk.title} (priority: ${tk.priority})`).join('\n')}
            onApply={() => {}}
          />
        </Card>
      )}

      <div className="flex gap-1.5 p-1 bg-gray-100 dark:bg-gray-800 rounded-xl">
        {filters.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-all ${
              filter === f.id
                ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                : 'text-gray-500 dark:text-gray-400'
            }`}
          >
            {t(f.labelKey)}
            <span className="ms-1.5 text-xs opacity-60">{f.count}</span>
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-400">{t('loading')}</div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<CheckSquare size={48} />}
          title={
            filter === 'today'
              ? t('noTasksToday')
              : filter === 'upcoming'
                ? t('noUpcomingTasks')
                : t('noCompletedTasks')
          }
          subtitle={t('getStarted')}
          action={
            <Button onClick={handleCreate} className="gap-1.5">
              <Plus size={18} />
              {t('newTask')}
            </Button>
          }
        />
      ) : (
        <div className="space-y-2">
          {filtered.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              onToggle={() => toggleComplete(task)}
              onEdit={() => {
                setEditing(task);
                setShowForm(true);
              }}
              onDelete={() => setDeleteTarget(task)}
              t={t}
              lang={language}
            />
          ))}
        </div>
      )}

      {showForm && (
        <TaskForm
          task={editing}
          onClose={() => setShowForm(false)}
          onSave={async (data) => {
            if (editing) {
              await update(editing.id, data);
            } else {
              await create(data);
            }
            setShowForm(false);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) await remove(deleteTarget.id);
          setDeleteTarget(null);
        }}
        title={t('delete')}
        message={t('deleteTaskConfirm')}
        confirmText={t('delete')}
      />
    </div>
  );
}

function TaskCard({
  task,
  onToggle,
  onEdit,
  onDelete,
  t,
  lang,
}: {
  task: Task;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  t: (k: TranslationKey) => string;
  lang: 'ar' | 'en';
}) {
  const priorityColors: Record<string, string> = {
    high: 'bg-red-500',
    normal: 'bg-purple-500',
    low: 'bg-gray-400',
  };

  return (
    <Card className="p-3.5 flex items-start gap-3">
      <button
        onClick={onToggle}
        className={`mt-0.5 w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
          task.completed
            ? 'bg-purple-600 border-purple-600 text-white'
            : 'border-gray-300 dark:border-gray-600 hover:border-purple-500'
        }`}
        aria-label={task.completed ? t('markIncomplete') : t('markComplete')}
      >
        {task.completed && <Check size={16} />}
      </button>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span
            className={`w-1.5 h-1.5 rounded-full ${priorityColors[task.priority] || 'bg-gray-400'}`}
          />
          <h3
            className={`text-sm font-medium truncate ${
              task.completed
                ? 'line-through text-gray-400 dark:text-gray-500'
                : 'text-gray-900 dark:text-gray-100'
            }`}
          >
            {task.title}
          </h3>
        </div>
        {task.details && (
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
            {task.details}
          </p>
        )}
        <div className="flex items-center gap-3 mt-1.5">
          {task.task_date && (
            <span className="text-xs text-gray-400 dark:text-gray-500 flex items-center gap-1">
              <Clock size={12} />
              {formatShortDate(task.task_date, lang)}
            </span>
          )}
          {task.reminder && (
            <span className="text-xs text-amber-500 flex items-center gap-1">
              <Bell size={12} />
              {task.reminder_time}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-0.5">
        <Button variant="ghost" size="icon" onClick={onEdit} className="h-8 w-8">
          <Edit3 size={15} />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={onDelete}
          className="h-8 w-8 text-red-500 hover:text-red-600"
        >
          <Trash2 size={15} />
        </Button>
      </div>
    </Card>
  );
}

function TaskForm({
  task,
  onClose,
  onSave,
}: {
  task: Task | null;
  onClose: () => void;
  onSave: (data: Partial<Task>) => Promise<void>;
}) {
  const { t } = useApp();
  const [title, setTitle] = useState(task?.title ?? '');
  const [details, setDetails] = useState(task?.details ?? '');
  const [taskDate, setTaskDate] = useState(task?.task_date ?? todayISODate());
  const [reminder, setReminder] = useState(task?.reminder ?? false);
  const [reminderTime, setReminderTime] = useState(task?.reminder_time ?? '09:00');
  const [priority, setPriority] = useState<Task['priority']>(task?.priority ?? 'normal');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    await onSave({
      title: title.trim(),
      details: details.trim() || null,
      task_date: taskDate || null,
      reminder,
      reminder_time: reminder ? reminderTime : null,
      priority,
    });
    setSaving(false);
  };

  return (
    <Modal open onClose={onClose} title={task ? t('editTask') : t('newTask')}>
      <div className="space-y-4">
        <div>
          <Label>{t('taskTitle')}</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('title')}
            autoFocus
          />
        </div>
        <div>
          <Label>{t('details')}</Label>
          <Textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder={t('addDetails')}
            rows={3}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>{t('date')}</Label>
            <Input type="date" value={taskDate} onChange={(e) => setTaskDate(e.target.value)} dir="ltr" />
          </div>
          <div>
            <Label>{t('priority')}</Label>
            <div className="flex gap-1 h-11">
              {(['low', 'normal', 'high'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={`flex-1 rounded-xl text-sm font-medium transition-all ${
                    priority === p
                      ? p === 'high'
                        ? 'bg-red-500 text-white'
                        : p === 'normal'
                          ? 'bg-purple-500 text-white'
                          : 'bg-gray-400 text-white'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                  }`}
                >
                  {t(p)}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setReminder(!reminder)}
            className={`flex items-center gap-2 px-4 h-11 rounded-xl text-sm font-medium transition-all ${
              reminder
                ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
            }`}
          >
            <Bell size={16} />
            {t('reminder')}
          </button>
          {reminder && (
            <Input
              type="time"
              value={reminderTime}
              onChange={(e) => setReminderTime(e.target.value)}
              className="w-32"
              dir="ltr"
            />
          )}
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button onClick={handleSave} disabled={saving || !title.trim()}>
            {t('save')}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
