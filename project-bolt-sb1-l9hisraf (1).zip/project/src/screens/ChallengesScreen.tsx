import { useMemo, useState } from 'react';
import { Plus, Trophy, Trash2, Edit3, Pause, Play, ChevronLeft, Calendar as CalIcon, Check } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useChallenges, useChallengeDays } from '@/hooks/useData';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Label, Textarea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { EmptyState } from '@/components/ui/EmptyState';
import { ConfirmDialog } from '@/components/AiAssistant';
import { AiAssistant } from '@/components/AiAssistant';
import { todayISODate } from '@/lib/utils';
import type { Challenge } from '@/types/database';

const COLORS = ['#a855f7', '#ec4899', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316'];

function getChallengeTotalDays(ch: Challenge): number {
  if (ch.duration_days) return ch.duration_days;
  if (ch.end_date) {
    const diff = Math.ceil(
      (new Date(ch.end_date).getTime() - new Date(ch.start_date).getTime()) / 86400000
    ) + 1;
    return Math.max(diff, 1);
  }
  return 30;
}

function getChallengeEndDate(ch: Challenge): string {
  if (ch.end_date) return ch.end_date;
  if (ch.duration_days) {
    const d = new Date(ch.start_date);
    d.setDate(d.getDate() + ch.duration_days - 1);
    return d.toISOString().split('T')[0];
  }
  return ch.start_date;
}

export function ChallengesScreen() {
  const { t, language } = useApp();
  const { challenges, loading, create, update, remove } = useChallenges();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Challenge | null>(null);
  const [detail, setDetail] = useState<Challenge | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Challenge | null>(null);

  const handleCreate = () => {
    setEditing(null);
    setShowForm(true);
  };

  const handleEdit = (ch: Challenge) => {
    setEditing(ch);
    setShowForm(true);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">{t('challenges')}</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            {challenges.length} {t('challenges')}
          </p>
        </div>
        <Button size="sm" onClick={handleCreate} className="gap-1.5">
          <Plus size={18} />
          {t('newChallenge')}
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-400">{t('loading')}</div>
      ) : challenges.length === 0 ? (
        <EmptyState
          icon={<Trophy size={48} />}
          title={t('noChallenges')}
          subtitle={t('getStarted')}
          action={
            <Button onClick={handleCreate} className="gap-1.5">
              <Plus size={18} />
              {t('newChallenge')}
            </Button>
          }
        />
      ) : (
        <div className="space-y-3">
          {challenges.map((ch) => (
            <ChallengeCard
              key={ch.id}
              challenge={ch}
              onOpen={() => setDetail(ch)}
              onEdit={() => handleEdit(ch)}
              onDelete={() => setDeleteTarget(ch)}
              onTogglePause={() =>
                update(ch.id, { status: ch.status === 'paused' ? 'active' : 'paused' })
              }
              t={t}
              lang={language}
            />
          ))}
        </div>
      )}

      {showForm && (
        <ChallengeForm
          challenge={editing}
          onClose={() => setShowForm(false)}
          onSave={async (data) => {
            if (editing) {
              await update(editing.id, data);
            } else {
              await create(data);
            }
            setShowForm(false);
          }}
        />
      )}

      {detail && (
        <ChallengeDetail
          challenge={detail}
          onClose={() => setDetail(null)}
          onEdit={() => {
            setDetail(null);
            handleEdit(detail);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) await remove(deleteTarget.id);
          setDeleteTarget(null);
        }}
        title={t('delete')}
        message={t('deleteChallengeConfirm')}
        confirmText={t('delete')}
      />
    </div>
  );
}

function ChallengeCard({
  challenge,
  onOpen,
  onEdit,
  onDelete,
  onTogglePause,
  t,
  lang,
}: {
  challenge: Challenge;
  onOpen: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onTogglePause: () => void;
  t: (k: import('@/lib/i18n').TranslationKey) => string;
  lang: 'ar' | 'en';
}) {
  const { days } = useChallengeDays(challenge.id);
  const total = getChallengeTotalDays(challenge);
  const completedCount = days.filter((d) => d.completed).length;
  const pct = total > 0 ? Math.min((completedCount / total) * 100, 100) : 0;
  const statusColor =
    challenge.status === 'active' ? 'bg-green-500' : challenge.status === 'paused' ? 'bg-amber-500' : 'bg-gray-400';
  const statusLabel =
    challenge.status === 'active' ? t('active') : challenge.status === 'paused' ? t('paused') : t('completedStatus');

  return (
    <Card className="overflow-hidden">
      <div onClick={onOpen} className="p-4 cursor-pointer">
        <div className="flex items-start gap-3 mb-3">
          <div
            className="w-1 self-stretch rounded-full flex-shrink-0 min-h-[44px]"
            style={{ backgroundColor: challenge.color || '#a855f7' }}
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate">
                {challenge.title}
              </h3>
              <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full text-white ${statusColor}`}>
                {statusLabel}
              </span>
            </div>
            {challenge.description && (
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                {challenge.description}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-gray-600 dark:text-gray-400">
            {completedCount} / {total} {t('days')}
          </span>
          <span className="text-gray-500 dark:text-gray-400 font-medium">
            {Math.round(pct)}%
          </span>
        </div>
        <div className="h-2 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${pct}%`, backgroundColor: challenge.color || '#a855f7' }}
          />
        </div>
      </div>

      <div className="flex items-center gap-1 px-3 pb-3 border-t border-gray-100 dark:border-gray-700/50 pt-2">
        <Button variant="ghost" size="sm" onClick={onTogglePause} className="gap-1.5">
          {challenge.status === 'paused' ? <Play size={15} /> : <Pause size={15} />}
          {challenge.status === 'paused' ? t('resume') : t('pause')}
        </Button>
        <Button variant="ghost" size="sm" onClick={onEdit} className="gap-1.5">
          <Edit3 size={15} />
          {t('edit')}
        </Button>
        <Button variant="ghost" size="sm" onClick={onDelete} className="gap-1.5 text-red-500 hover:text-red-600 ms-auto">
          <Trash2 size={15} />
        </Button>
      </div>
    </Card>
  );
}

function ChallengeForm({
  challenge,
  onClose,
  onSave,
}: {
  challenge: Challenge | null;
  onClose: () => void;
  onSave: (data: Partial<Challenge>) => Promise<void>;
}) {
  const { t } = useApp();
  const [title, setTitle] = useState(challenge?.title ?? '');
  const [description, setDescription] = useState(challenge?.description ?? '');
  const [startDate, setStartDate] = useState(challenge?.start_date ?? todayISODate());
  const [endDate, setEndDate] = useState(challenge?.end_date ?? '');
  const [durationDays, setDurationDays] = useState(
    challenge?.duration_days?.toString() ?? ''
  );
  const [color, setColor] = useState(challenge?.color ?? '#a855f7');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    const data: Partial<Challenge> = {
      title: title.trim(),
      description: description.trim() || null,
      start_date: startDate,
      end_date: durationDays ? null : endDate || null,
      duration_days: durationDays ? parseInt(durationDays, 10) : null,
      color,
    };
    await onSave(data);
    setSaving(false);
  };

  return (
    <Modal open onClose={onClose} title={challenge ? t('editChallenge') : t('newChallenge')}>
      <div className="space-y-4">
        <div>
          <Label>{t('challengeTitle')}</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t('title')} autoFocus />
        </div>
        <div>
          <Label>{t('description')}</Label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t('description')}
            rows={3}
          />
        </div>
        <div>
          <Label>{t('startDate')}</Label>
          <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} dir="ltr" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>{t('endDate')}</Label>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              disabled={!!durationDays}
              dir="ltr"
            />
          </div>
          <div>
            <Label>{t('orNumberOfDays')}</Label>
            <Input
              type="number"
              min={1}
              value={durationDays}
              onChange={(e) => setDurationDays(e.target.value)}
              placeholder={t('numberOfDays')}
              disabled={!!endDate}
              dir="ltr"
            />
          </div>
        </div>
        <div>
          <Label>{t('color')}</Label>
          <div className="flex gap-2 flex-wrap">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-9 h-9 rounded-full transition-transform ${color === c ? 'ring-2 ring-offset-2 ring-gray-400 dark:ring-offset-gray-800 scale-110' : ''}`}
                style={{ backgroundColor: c }}
                aria-label={c}
              />
            ))}
          </div>
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>{t('cancel')}</Button>
          <Button onClick={handleSave} disabled={saving || !title.trim()}>
            {t('save')}
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function ChallengeDetail({
  challenge,
  onClose,
  onEdit,
}: {
  challenge: Challenge;
  onClose: () => void;
  onEdit: () => void;
}) {
  const { t, language } = useApp();
  const { days, toggleDay } = useChallengeDays(challenge.id);
  const [showAi, setShowAi] = useState(false);

  const total = getChallengeTotalDays(challenge);
  const completedCount = days.filter((d) => d.completed).length;
  const pct = total > 0 ? Math.min((completedCount / total) * 100, 100) : 0;

  const calendarDays = useMemo(() => {
    const start = new Date(challenge.start_date);
    const end = new Date(getChallengeEndDate(challenge));
    const arr: { date: string; completed: boolean; isToday: boolean }[] = [];
    const today = todayISODate();
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split('T')[0];
      const dayRecord = days.find((dy) => dy.day_date === dateStr);
      arr.push({
        date: dateStr,
        completed: dayRecord?.completed ?? false,
        isToday: dateStr === today,
      });
    }
    return arr;
  }, [challenge, days]);

  const monthLabel = new Date(challenge.start_date).toLocaleDateString(
    language === 'ar' ? 'ar-EG' : 'en-US',
    { month: 'long', year: 'numeric' }
  );

  return (
    <Modal open onClose={onClose} title={challenge.title} size="xl">
      <div className="space-y-5">
        {challenge.description && (
          <p className="text-sm text-gray-600 dark:text-gray-400">{challenge.description}</p>
        )}

        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600 dark:text-gray-400">
            {completedCount} / {total} {t('days')}
          </span>
          <span className="font-semibold text-gray-900 dark:text-gray-100">{Math.round(pct)}%</span>
        </div>
        <div className="h-3 rounded-full bg-gray-100 dark:bg-gray-700 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${pct}%`, backgroundColor: challenge.color || '#a855f7' }}
          />
        </div>

        <div>
          <div className="flex items-center gap-2 mb-3">
            <CalIcon size={18} className="text-gray-400" />
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
              {t('calendarView')} — {monthLabel}
            </h3>
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {calendarDays.map((cd) => (
              <button
                key={cd.date}
                onClick={() => toggleDay(cd.date, !cd.completed)}
                className={`aspect-square rounded-lg text-xs font-medium transition-all flex items-center justify-center relative ${
                  cd.completed
                    ? 'text-white shadow-sm'
                    : 'bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                } ${cd.isToday ? 'ring-2 ring-purple-500 ring-offset-1 dark:ring-offset-gray-800' : ''}`}
                style={cd.completed ? { backgroundColor: challenge.color || '#a855f7' } : undefined}
              >
                {cd.completed ? <Check size={14} /> : new Date(cd.date).getDate()}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-gray-100 dark:border-gray-700/50">
          <Button variant="ghost" size="sm" onClick={onEdit} className="gap-1.5">
            <Edit3 size={15} />
            {t('edit')}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowAi(!showAi)} className="gap-1.5">
            <span className="text-purple-500">✦</span>
            {t('aiAssistant')}
          </Button>
        </div>

        {showAi && (
          <div className="pt-2">
            <AiAssistant
              action="organize_challenge"
              content={`${challenge.title}\n${challenge.description || ''}\nStart: ${challenge.start_date}\nDuration: ${total} days\nCompleted: ${completedCount} days`}
              onApply={() => {}}
            />
          </div>
        )}
      </div>
    </Modal>
  );
}
