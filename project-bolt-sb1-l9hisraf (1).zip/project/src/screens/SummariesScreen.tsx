import { useState } from 'react';
import {
  Plus,
  FileText,
  Network,
  Trash2,
  Edit3,
  X,
  ChevronDown,
  ChevronUp,
  Sparkles,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useSummaries, useMindMaps } from '@/hooks/useData';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Label, Textarea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { EmptyState } from '@/components/ui/EmptyState';
import { ConfirmDialog, AiAssistant } from '@/components/AiAssistant';
import { relativeTime } from '@/lib/utils';
import type { Summary, MindMap, MindMapNode } from '@/types/database';
import type { TranslationKey } from '@/lib/i18n';

type Tab = 'summaries' | 'mindmaps';

export function SummariesScreen() {
  const { t, language } = useApp();
  const [tab, setTab] = useState<Tab>('summaries');

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-white">
          {t('summariesAndMindMaps')}
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
          {t('organizeByDate')}
        </p>
      </div>

      <div className="flex gap-1.5 p-1 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <button
          onClick={() => setTab('summaries')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
            tab === 'summaries'
              ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
              : 'text-gray-500 dark:text-gray-400'
          }`}
        >
          <FileText size={16} />
          {t('summariesTab')}
        </button>
        <button
          onClick={() => setTab('mindmaps')}
          className={`flex-1 py-2.5 px-3 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
            tab === 'mindmaps'
              ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
              : 'text-gray-500 dark:text-gray-400'
          }`}
        >
          <Network size={16} />
          {t('mindMapsTab')}
        </button>
      </div>

      {tab === 'summaries' ? <SummariesList lang={language} /> : <MindMapsList lang={language} />}
    </div>
  );
}

// ============================================================================
// Summaries
// ============================================================================

function SummariesList({ lang }: { lang: 'ar' | 'en' }) {
  const { t } = useApp();
  const { summaries, loading, create, update, remove } = useSummaries();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Summary | null>(null);
  const [viewing, setViewing] = useState<Summary | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Summary | null>(null);

  return (
    <div className="space-y-3">
      <Button
        size="sm"
        onClick={() => {
          setEditing(null);
          setShowForm(true);
        }}
        className="gap-1.5 w-full"
      >
        <Plus size={18} />
        {t('newSummary')}
      </Button>

      {loading ? (
        <div className="text-center py-12 text-gray-400">{t('loading')}</div>
      ) : summaries.length === 0 ? (
        <EmptyState
          icon={<FileText size={48} />}
          title={t('noSummaries')}
          subtitle={t('getStarted')}
        />
      ) : (
        <div className="space-y-2.5">
          {summaries.map((s) => (
            <Card key={s.id} onClick={() => setViewing(s)} className="p-4">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate flex-1">
                  {s.title}
                </h3>
                <div className="flex items-center gap-0.5 flex-shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditing(s);
                      setShowForm(true);
                    }}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <Edit3 size={15} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteTarget(s);
                    }}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
              {s.content && (
                <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 whitespace-pre-wrap">
                  {s.content}
                </p>
              )}
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                {relativeTime(s.updated_at, lang)}
              </p>
            </Card>
          ))}
        </div>
      )}

      {showForm && (
        <SummaryForm
          summary={editing}
          onClose={() => setShowForm(false)}
          onSave={async (data) => {
            if (editing) {
              await update(editing.id, data);
            } else {
              await create(data);
            }
            setShowForm(false);
          }}
        />
      )}

      {viewing && (
        <SummaryViewer
          summary={viewing}
          onClose={() => setViewing(null)}
          onEdit={() => {
            setViewing(null);
            setEditing(viewing);
            setShowForm(true);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) await remove(deleteTarget.id);
          setDeleteTarget(null);
        }}
        title={t('delete')}
        message={t('deleteSummaryConfirm')}
        confirmText={t('delete')}
      />
    </div>
  );
}

function SummaryForm({
  summary,
  onClose,
  onSave,
}: {
  summary: Summary | null;
  onClose: () => void;
  onSave: (data: Partial<Summary>) => Promise<void>;
}) {
  const { t } = useApp();
  const [title, setTitle] = useState(summary?.title ?? '');
  const [content, setContent] = useState(summary?.content ?? '');
  const [saving, setSaving] = useState(false);
  const [showAi, setShowAi] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    await onSave({
      title: title.trim(),
      content: content.trim() || null,
    });
    setSaving(false);
  };

  return (
    <Modal open onClose={onClose} title={summary ? t('editSummary') : t('newSummary')} size="lg">
      <div className="space-y-4">
        <div>
          <Label>{t('summaryTitle')}</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('title')}
            autoFocus
          />
        </div>
        <div>
          <Label>{t('writeFreely')}</Label>
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('writeFreely')}
            rows={10}
          />
          <p className="text-xs text-gray-400 mt-1.5">
            {t('headings')}: # {t('title')} · {t('bulletPoints')}: -
          </p>
        </div>

        {content.trim() && (
          <div>
            <Button variant="ghost" size="sm" onClick={() => setShowAi(!showAi)} className="gap-1.5">
              <Sparkles size={16} className="text-purple-500" />
              {t('aiAssistant')}
            </Button>
            {showAi && (
              <div className="mt-2">
                <AiAssistant
                  action="organize_summary"
                  content={content}
                  onApply={(result) => {
                    setContent(result);
                    setShowAi(false);
                  }}
                />
              </div>
            )}
          </div>
        )}

        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button onClick={handleSave} disabled={saving || !title.trim()}>
            {t('save')}
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function SummaryViewer({
  summary,
  onClose,
  onEdit,
}: {
  summary: Summary;
  onClose: () => void;
  onEdit: () => void;
}) {
  const { t, language } = useApp();
  const [showAi, setShowAi] = useState(false);

  return (
    <Modal open onClose={onClose} title={summary.title} size="lg">
      <div className="space-y-4">
        <SummaryContent content={summary.content || ''} />
        <p className="text-xs text-gray-400 dark:text-gray-500">
          {relativeTime(summary.updated_at, language)}
        </p>
        <div className="flex items-center justify-between pt-3 border-t border-gray-100 dark:border-gray-700/50">
          <Button variant="ghost" size="sm" onClick={onEdit} className="gap-1.5">
            <Edit3 size={15} />
            {t('edit')}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowAi(!showAi)} className="gap-1.5">
            <Sparkles size={16} className="text-purple-500" />
            {t('aiAssistant')}
          </Button>
        </div>
        {showAi && summary.content && (
          <AiAssistant
            action="organize_summary"
            content={summary.content}
            onApply={() => {}}
          />
        )}
      </div>
    </Modal>
  );
}

function SummaryContent({ content }: { content: string }) {
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let inBullets = false;
  let bulletItems: React.ReactNode[] = [];

  const flushBullets = (key: number) => {
    if (bulletItems.length > 0) {
      elements.push(
        <ul key={`bullets-${key}`} className="space-y-1 my-2 ms-4">
          {bulletItems}
        </ul>
      );
      bulletItems = [];
    }
  };

  lines.forEach((line, i) => {
    const trimmed = line.trim();
    if (trimmed.startsWith('# ')) {
      flushBullets(i);
      inBullets = false;
      elements.push(
        <h3 key={i} className="text-base font-bold text-gray-900 dark:text-gray-100 mt-3 mb-1">
          {trimmed.slice(2)}
        </h3>
      );
    } else if (trimmed.startsWith('## ')) {
      flushBullets(i);
      inBullets = false;
      elements.push(
        <h4 key={i} className="text-sm font-semibold text-gray-800 dark:text-gray-200 mt-2 mb-1">
          {trimmed.slice(3)}
        </h4>
      );
    } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      inBullets = true;
      bulletItems.push(
        <li key={i} className="text-sm text-gray-700 dark:text-gray-300 flex items-start gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-gray-400 mt-2 flex-shrink-0" />
          <span>{trimmed.slice(2)}</span>
        </li>
      );
    } else if (trimmed) {
      flushBullets(i);
      inBullets = false;
      elements.push(
        <p key={i} className="text-sm text-gray-700 dark:text-gray-300 my-1">
          {trimmed}
        </p>
      );
    }
  });
  flushBullets(999);

  if (elements.length === 0) {
    return <p className="text-sm text-gray-400 italic">No content</p>;
  }

  return <div>{elements}</div>;
}

// ============================================================================
// Mind Maps
// ============================================================================

function MindMapsList({ lang }: { lang: 'ar' | 'en' }) {
  const { t } = useApp();
  const { mindMaps, loading, create, update, remove } = useMindMaps();
  const [editing, setEditing] = useState<MindMap | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<MindMap | null>(null);

  const handleCreate = async () => {
    const rootNode: MindMapNode = {
      id: 'root',
      text: t('centralTopic'),
      children: [],
    };
    const created = await create({
      title: t('newMindMap'),
      data: rootNode,
    });
    setEditing(created);
  };

  return (
    <div className="space-y-3">
      <Button size="sm" onClick={handleCreate} className="gap-1.5 w-full">
        <Plus size={18} />
        {t('newMindMap')}
      </Button>

      {loading ? (
        <div className="text-center py-12 text-gray-400">{t('loading')}</div>
      ) : mindMaps.length === 0 ? (
        <EmptyState
          icon={<Network size={48} />}
          title={t('noMindMaps')}
          subtitle={t('getStarted')}
        />
      ) : (
        <div className="space-y-2.5">
          {mindMaps.map((mm) => (
            <Card key={mm.id} onClick={() => setEditing(mm)} className="p-4">
              <div className="flex items-start justify-between gap-2 mb-1">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <Network size={18} className="text-violet-500 flex-shrink-0" />
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate">
                    {mm.title}
                  </h3>
                </div>
                <div className="flex items-center gap-0.5 flex-shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditing(mm);
                    }}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <Edit3 size={15} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteTarget(mm);
                    }}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                {mm.data.children.length} {t('branches')} · {relativeTime(mm.updated_at, lang)}
              </p>
            </Card>
          ))}
        </div>
      )}

      {editing && (
        <MindMapEditor
          mindMap={editing}
          onClose={() => setEditing(null)}
          onSave={async (title, data) => {
            await update(editing.id, { title, data });
            setEditing(null);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) await remove(deleteTarget.id);
          setDeleteTarget(null);
        }}
        title={t('delete')}
        message={t('deleteMindMapConfirm')}
        confirmText={t('delete')}
      />
    </div>
  );
}

let nodeIdCounter = 0;
function genId(): string {
  nodeIdCounter++;
  return `node-${Date.now()}-${nodeIdCounter}`;
}

function updateNode(node: MindMapNode, id: string, updater: (n: MindMapNode) => MindMapNode): MindMapNode {
  if (node.id === id) return updater(node);
  return {
    ...node,
    children: node.children.map((c) => updateNode(c, id, updater)),
  };
}

function removeNode(node: MindMapNode, id: string): MindMapNode {
  return {
    ...node,
    children: node.children
      .filter((c) => c.id !== id)
      .map((c) => removeNode(c, id)),
  };
}

function addChildToNode(node: MindMapNode, id: string, child: MindMapNode): MindMapNode {
  if (node.id === id) {
    return { ...node, children: [...node.children, child] };
  }
  return {
    ...node,
    children: node.children.map((c) => addChildToNode(c, id, child)),
  };
}

function MindMapEditor({
  mindMap,
  onClose,
  onSave,
}: {
  mindMap: MindMap;
  onClose: () => void;
  onSave: (title: string, data: MindMapNode) => Promise<void>;
}) {
  const { t } = useApp();
  const [title, setTitle] = useState(mindMap.title);
  const [tree, setTree] = useState<MindMapNode>(mindMap.data);
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['root']));
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [showAi, setShowAi] = useState(false);
  const [saving, setSaving] = useState(false);

  const toggleExpand = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const startEdit = (node: MindMapNode) => {
    setEditingId(node.id);
    setEditText(node.text);
  };

  const commitEdit = () => {
    if (!editingId) return;
    setTree((prev) => updateNode(prev, editingId, (n) => ({ ...n, text: editText.trim() || n.text })));
    setEditingId(null);
    setEditText('');
  };

  const addBranch = (parentId: string) => {
    const newNode: MindMapNode = { id: genId(), text: t('addBranch'), children: [] };
    setTree((prev) => addChildToNode(prev, parentId, newNode));
    setExpanded((prev) => new Set(prev).add(parentId));
  };

  const deleteBranch = (id: string) => {
    if (id === 'root') return;
    setTree((prev) => removeNode(prev, id));
  };

  const handleSave = async () => {
    setSaving(true);
    await onSave(title.trim() || t('newMindMap'), tree);
    setSaving(false);
  };

  const applyAiResult = (result: string) => {
    try {
      const cleaned = result.replace(/```json|```/g, '').trim();
      const parsed = JSON.parse(cleaned) as MindMapNode;
      if (parsed.id && parsed.text) {
        setTree(parsed);
        setExpanded(new Set(['root']));
      }
    } catch {
      // ignore parse errors
    }
  };

  const renderNode = (node: MindMapNode, level: number, isRoot: boolean): React.ReactNode => {
    const isExpanded = expanded.has(node.id);
    const isEditing = editingId === node.id;

    return (
      <div key={node.id} className={level > 0 ? 'ms-4 ps-3 border-s-2 border-gray-200 dark:border-gray-700' : ''}>
        <div className="flex items-center gap-1.5 py-1.5 group">
          {node.children.length > 0 ? (
            <button
              onClick={() => toggleExpand(node.id)}
              className="p-0.5 rounded text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              {isExpanded ? <ChevronDown size={16} /> : <ChevronUp size={16} className="rtl:rotate-180" />}
            </button>
          ) : (
            <span className="w-5" />
          )}

          {isEditing ? (
            <input
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onBlur={commitEdit}
              onKeyDown={(e) => {
                if (e.key === 'Enter') commitEdit();
                if (e.key === 'Escape') setEditingId(null);
              }}
              autoFocus
              className={`flex-1 h-8 px-2 rounded-lg border text-sm ${
                isRoot
                  ? 'border-violet-400 bg-violet-50 dark:bg-violet-900/20 font-semibold'
                  : 'border-purple-400 bg-purple-50 dark:bg-purple-900/20'
              } text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-purple-500`}
            />
          ) : (
            <button
              onClick={() => startEdit(node)}
              className={`flex-1 text-start text-sm px-2 py-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors truncate ${
                isRoot
                  ? 'font-bold text-gray-900 dark:text-white text-base'
                  : 'text-gray-700 dark:text-gray-300'
              }`}
            >
              {node.text}
            </button>
          )}

          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => addBranch(node.id)}
              className="p-1 rounded text-gray-400 hover:text-purple-500 hover:bg-gray-100 dark:hover:bg-gray-700"
              title={t('addSubBranch')}
            >
              <Plus size={14} />
            </button>
            {!isRoot && (
              <button
                onClick={() => deleteBranch(node.id)}
                className="p-1 rounded text-gray-400 hover:text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>

        {isExpanded && node.children.length > 0 && (
          <div className="mt-0.5">
            {node.children.map((child) => renderNode(child, level + 1, false))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Modal open onClose={onClose} title={t('editMindMap')} size="xl">
      <div className="space-y-4">
        <div>
          <Label>{t('mindMapTitle')}</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t('title')} />
        </div>

        <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/30 p-4 min-h-[200px] max-h-[400px] overflow-y-auto">
          {renderNode(tree, 0, true)}
        </div>

        <p className="text-xs text-gray-400 dark:text-gray-500">
          {t('moveNodeHint')}
        </p>

        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="secondary" size="sm" onClick={() => setShowAi(!showAi)} className="gap-1.5">
            <Sparkles size={16} className="text-purple-500" />
            {t('generateMindMap')}
          </Button>
          {showAi && (
            <AiAssistant
              action="generate_mindmap"
              content={tree.text + ' ' + JSON.stringify(tree)}
              onApply={applyAiResult}
            />
          )}
        </div>

        <div className="flex gap-2 justify-end pt-2 border-t border-gray-100 dark:border-gray-700/50">
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {t('save')}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
