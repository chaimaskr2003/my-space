import { Trophy, CheckSquare, NotebookPen, Network, ChevronRight, Calendar } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useAuth } from '@/context/AuthContext';
import { Card } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/EmptyState';
import { useChallenges, useTasks, useNotes, useSummaries } from '@/hooks/useData';
import { formatDate, getGreetingHour, relativeTime, todayISODate } from '@/lib/utils';
import type { TabId } from '@/components/BottomNav';
import type { TranslationKey } from '@/lib/i18n';

export function HomeScreen({ onNavigate }: { onNavigate: (tab: TabId) => void }) {
  const { t, language } = useApp();
  const { profile } = useAuth();
  const { challenges } = useChallenges();
  const { tasks } = useTasks();
  const { notes } = useNotes();
  const { summaries } = useSummaries();

  const greeting = getGreetingHour();
  const greetingKey: TranslationKey =
    greeting === 'morning' ? 'goodMorning' : greeting === 'afternoon' ? 'goodAfternoon' : 'goodEvening';
  const displayName = profile?.display_name || '';

  const today = todayISODate();
  const activeChallenges = challenges.filter((c) => c.status === 'active');
  const todaysTasks = tasks.filter(
    (tk) => tk.task_date === today && !tk.completed
  );
  const recentNotes = notes.filter((n) => !n.is_secure).slice(0, 3);
  const recentSummaries = summaries.slice(0, 3);

  const quickLinks: { tab: TabId; icon: typeof Trophy; label: TranslationKey; color: string }[] = [
    { tab: 'challenges', icon: Trophy, label: 'challenges', color: 'bg-amber-500' },
    { tab: 'tasks', icon: CheckSquare, label: 'tasks', color: 'bg-pink-500' },
    { tab: 'notes', icon: NotebookPen, label: 'notes', color: 'bg-emerald-500' },
    { tab: 'summaries', icon: Network, label: 'summaries', color: 'bg-violet-500' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-gray-500 dark:text-gray-400">{t(greetingKey)}</p>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mt-0.5">
          {displayName}
        </h1>
        <div className="flex items-center gap-1.5 mt-2 text-sm text-gray-500 dark:text-gray-400">
          <Calendar size={15} />
          <span>{formatDate(new Date().toISOString(), language)}</span>
        </div>
      </div>

      <section>
        <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">
          {t('quickAccess')}
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Card
                key={link.tab}
                onClick={() => onNavigate(link.tab)}
                className="p-4 flex items-center gap-3"
              >
                <div className={`w-10 h-10 rounded-xl ${link.color} text-white flex items-center justify-center flex-shrink-0`}>
                  <Icon size={20} />
                </div>
                <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
                  {t(link.label)}
                </span>
              </Card>
            );
          })}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
            {t('activeChallenges')}
          </h2>
          <button
            onClick={() => onNavigate('challenges')}
            className="text-xs font-medium text-purple-600 dark:text-purple-400 hover:underline"
          >
            {t('viewAll')}
          </button>
        </div>
        {activeChallenges.length === 0 ? (
          <Card className="p-4">
            <p className="text-sm text-gray-400 dark:text-gray-500 text-center py-2">
              {t('noActiveChallenges')}
            </p>
          </Card>
        ) : (
          <div className="space-y-2">
            {activeChallenges.slice(0, 3).map((ch) => {
              const total = ch.duration_days ?? (ch.end_date ? 30 : 30);
              return (
                <Card
                  key={ch.id}
                  onClick={() => onNavigate('challenges')}
                  className="p-4 flex items-center gap-3"
                >
                  <div
                    className="w-1.5 h-10 rounded-full flex-shrink-0"
                    style={{ backgroundColor: ch.color || '#3b82f6' }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                      {ch.title}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                      {t('progress')}: {total} {t('days')}
                    </p>
                  </div>
                  <ChevronRight size={18} className="text-gray-400 rtl:rotate-180" />
                </Card>
              );
            })}
          </div>
        )}
      </section>

      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
            {t('todaysTasks')}
          </h2>
          <button
            onClick={() => onNavigate('tasks')}
            className="text-xs font-medium text-purple-600 dark:text-purple-400 hover:underline"
          >
            {t('viewAll')}
          </button>
        </div>
        {todaysTasks.length === 0 ? (
          <Card className="p-4">
            <p className="text-sm text-gray-400 dark:text-gray-500 text-center py-2">
              {t('noTasksToday')}
            </p>
          </Card>
        ) : (
          <div className="space-y-2">
            {todaysTasks.slice(0, 5).map((task) => (
              <Card key={task.id} className="p-3.5 flex items-center gap-3">
                <div className="w-5 h-5 rounded-full border-2 border-gray-300 dark:border-gray-600 flex-shrink-0" />
                <span className="text-sm text-gray-800 dark:text-gray-200 flex-1 truncate">
                  {task.title}
                </span>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">
          {t('recentNotes')}
        </h2>
        {recentNotes.length === 0 && recentSummaries.length === 0 ? (
          <EmptyState icon={<NotebookPen size={48} />} title={t('noNotes')} />
        ) : (
          <div className="space-y-2">
            {recentNotes.map((note) => (
              <Card key={note.id} onClick={() => onNavigate('notes')} className="p-4">
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
                  {note.title}
                </p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                  {relativeTime(note.updated_at, language)}
                </p>
              </Card>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
