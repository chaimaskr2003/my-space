import { useEffect, useMemo, useState } from 'react';
import {
  Plus,
  NotebookPen,
  Trash2,
  Edit3,
  Search,
  Lock,
  Shield,
  Eye,
  EyeOff,
  AlertTriangle,
  X,
  KeyRound,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useNotes } from '@/hooks/useData';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Label, Textarea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { EmptyState } from '@/components/ui/EmptyState';
import { ConfirmDialog, AiAssistant } from '@/components/AiAssistant';
import { encryptContent, decryptContent } from '@/lib/crypto';
import { relativeTime } from '@/lib/utils';
import type { Note } from '@/types/database';

const PIN_STORAGE_KEY = 'myspace-vault-pin-set';
const SESSION_KEY = 'myspace-vault-session';

export function NotesScreen() {
  const { t, language } = useApp();
  const { notes, loading, create, update, remove } = useNotes();
  const [query, setQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Note | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Note | null>(null);
  const [viewing, setViewing] = useState<Note | null>(null);
  const [vaultOpen, setVaultOpen] = useState(false);

  const regularNotes = notes.filter((n) => !n.is_secure);
  const secureNotes = notes.filter((n) => n.is_secure);

  const filtered = useMemo(() => {
    if (!query.trim()) return regularNotes;
    const q = query.toLowerCase();
    return regularNotes.filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        (n.content?.toLowerCase().includes(q) ?? false)
    );
  }, [regularNotes, query]);

  const handleCreate = () => {
    setEditing(null);
    setShowForm(true);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">{t('notes')}</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            {regularNotes.length} {t('notes').toLowerCase()}
          </p>
        </div>
        <Button size="sm" onClick={handleCreate} className="gap-1.5">
          <Plus size={18} />
          {t('newNote')}
        </Button>
      </div>

      <div className="relative">
        <Search size={18} className="absolute top-3.5 start-3.5 text-gray-400" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('search')}
          className="ps-11"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute top-3 end-3 text-gray-400 hover:text-gray-600"
          >
            <X size={18} />
          </button>
        )}
      </div>

      <VaultCard
        secureCount={secureNotes.length}
        onOpen={() => setVaultOpen(true)}
      />

      {loading ? (
        <div className="text-center py-12 text-gray-400">{t('loading')}</div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<NotebookPen size={48} />}
          title={query ? t('noNotes') : t('noNotes')}
          subtitle={t('getStarted')}
          action={
            !query && (
              <Button onClick={handleCreate} className="gap-1.5">
                <Plus size={18} />
                {t('newNote')}
              </Button>
            )
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-2.5">
          {filtered.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onView={() => setViewing(note)}
              onEdit={() => {
                setEditing(note);
                setShowForm(true);
              }}
              onDelete={() => setDeleteTarget(note)}
              t={t}
              lang={language}
            />
          ))}
        </div>
      )}

      {showForm && (
        <NoteForm
          note={editing}
          onClose={() => setShowForm(false)}
          onSave={async (data) => {
            if (editing) {
              await update(editing.id, data);
            } else {
              await create(data);
            }
            setShowForm(false);
          }}
        />
      )}

      {viewing && (
        <NoteViewer
          note={viewing}
          onClose={() => setViewing(null)}
          onEdit={() => {
            setViewing(null);
            setEditing(viewing);
            setShowForm(true);
          }}
        />
      )}

      {vaultOpen && (
        <VaultScreen onClose={() => setVaultOpen(false)} />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) await remove(deleteTarget.id);
          setDeleteTarget(null);
          setViewing(null);
        }}
        title={t('delete')}
        message={t('deleteNoteConfirm')}
        confirmText={t('delete')}
      />
    </div>
  );
}

function NoteCard({
  note,
  onView,
  onEdit,
  onDelete,
  t,
  lang,
}: {
  note: Note;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
  t: (k: import('@/lib/i18n').TranslationKey) => string;
  lang: 'ar' | 'en';
}) {
  return (
    <Card onClick={onView} className="p-4">
      <div className="flex items-start justify-between gap-2 mb-1">
        <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate flex-1">
          {note.title}
        </h3>
        <div className="flex items-center gap-0.5 flex-shrink-0">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit();
            }}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <Edit3 size={15} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <Trash2 size={15} />
          </button>
        </div>
      </div>
      {note.content && (
        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-3 whitespace-pre-wrap">
          {note.content}
        </p>
      )}
      <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
        {relativeTime(note.updated_at, lang)}
      </p>
    </Card>
  );
}

function NoteForm({
  note,
  onClose,
  onSave,
}: {
  note: Note | null;
  onClose: () => void;
  onSave: (data: Partial<Note>) => Promise<void>;
}) {
  const { t } = useApp();
  const [title, setTitle] = useState(note?.title ?? '');
  const [content, setContent] = useState(note?.content ?? '');
  const [saving, setSaving] = useState(false);
  const [showAi, setShowAi] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    setSaveError(null);
    try {
      await onSave({
        title: title.trim(),
        content: content.trim() || null,
      });
    } catch {
      setSaveError(t('error'));
      setSaving(false);
    }
  };

  return (
    <Modal open onClose={onClose} title={note ? t('editNote') : t('newNote')} size="lg">
      <div className="space-y-4">
        <div>
          <Label>{t('noteTitle')}</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('title')}
            autoFocus
          />
        </div>
        <div>
          <Label>{t('writeFreely')}</Label>
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('writeFreely')}
            rows={10}
          />
        </div>

        {content.trim() && (
          <div>
            <Button variant="ghost" size="sm" onClick={() => setShowAi(!showAi)} className="gap-1.5">
              <span className="text-purple-500">✦</span>
              {t('aiAssistant')}
            </Button>
            {showAi && (
              <div className="mt-2">
                <AiAssistant
                  action="summarize_note"
                  content={content}
                  onApply={(result) => {
                    setContent(content + '\n\n---\n' + result);
                    setShowAi(false);
                  }}
                />
              </div>
            )}
          </div>
        )}

        {saveError && (
          <div className="text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 rounded-lg px-3 py-2">
            {saveError}
          </div>
        )}

        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button onClick={handleSave} disabled={saving || !title.trim()}>
            {t('save')}
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function NoteViewer({
  note,
  onClose,
  onEdit,
}: {
  note: Note;
  onClose: () => void;
  onEdit: () => void;
}) {
  const { t, language } = useApp();
  const [showAi, setShowAi] = useState(false);

  return (
    <Modal open onClose={onClose} title={note.title} size="lg">
      <div className="space-y-4">
        <div className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed min-h-[120px]">
          {note.content || t('noDetails')}
        </div>
        <p className="text-xs text-gray-400 dark:text-gray-500">
          {relativeTime(note.updated_at, language)}
        </p>

        <div className="flex items-center justify-between pt-3 border-t border-gray-100 dark:border-gray-700/50">
          <Button variant="ghost" size="sm" onClick={onEdit} className="gap-1.5">
            <Edit3 size={15} />
            {t('edit')}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setShowAi(!showAi)} className="gap-1.5">
            <span className="text-purple-500">✦</span>
            {t('aiAssistant')}
          </Button>
        </div>

        {showAi && note.content && (
          <AiAssistant
            action="summarize_note"
            content={note.content}
            onApply={() => {}}
          />
        )}
      </div>
    </Modal>
  );
}

// ============================================================================
// Secure Vault
// ============================================================================

function VaultCard({ secureCount, onOpen }: { secureCount: number; onOpen: () => void }) {
  const { t } = useApp();
  return (
    <Card onClick={onOpen} className="p-4 flex items-center gap-3 bg-gradient-to-br from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-900 border-gray-700 dark:border-gray-700">
      <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
        <Shield size={22} className="text-white" />
      </div>
      <div className="flex-1">
        <h3 className="font-semibold text-white">{t('secureVault')}</h3>
        <p className="text-xs text-gray-300 mt-0.5">
          {secureCount} {t('secureNotes')}
        </p>
      </div>
      <Lock size={18} className="text-gray-400" />
    </Card>
  );
}

function VaultScreen({ onClose }: { onClose: () => void }) {
  const { t } = useApp();
  const { notes, create, update, remove } = useNotes();
  const [phase, setPhase] = useState<'enter' | 'set' | 'main'>('enter');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Note | null>(null);
  const [decryptedMap, setDecryptedMap] = useState<Record<string, string>>({});
  const [visibleIds, setVisibleIds] = useState<Set<string>>(new Set());
  const [showReset, setShowReset] = useState(false);

  const pinSet = localStorage.getItem(PIN_STORAGE_KEY) === 'true';
  const secureNotes = notes.filter((n) => n.is_secure);

  useEffect(() => {
    if (!pinSet) setPhase('set');
  }, [pinSet]);

  const handleSetPin = async () => {
    setError(null);
    if (pin.length !== 4 || !/^\d{4}$/.test(pin)) {
      setError(t('enterPin'));
      return;
    }
    if (pin !== confirmPin) {
      setError(t('pinIncorrect'));
      return;
    }
    localStorage.setItem(PIN_STORAGE_KEY, 'true');
    sessionStorage.setItem(SESSION_KEY, pin);
    setPhase('main');
  };

  const handleEnterPin = async () => {
    setError(null);
    if (pin.length !== 4) {
      setError(t('enterPin'));
      return;
    }
    try {
      const testNote = secureNotes[0];
      if (testNote?.encrypted_content) {
        await decryptContent(testNote.encrypted_content, pin);
      }
      sessionStorage.setItem(SESSION_KEY, pin);
      setPhase('main');
    } catch {
      setError(t('pinIncorrect'));
    }
  };

  const resetVault = async () => {
    for (const note of secureNotes) {
      await remove(note.id);
    }
    localStorage.removeItem(PIN_STORAGE_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    setPhase('set');
    setPin('');
    setConfirmPin('');
    setShowReset(false);
  };

  const toggleVisible = async (note: Note) => {
    if (!note.encrypted_content) return;
    const currentPin = sessionStorage.getItem(SESSION_KEY);
    if (!currentPin) return;

    if (visibleIds.has(note.id)) {
      setVisibleIds((prev) => {
        const next = new Set(prev);
        next.delete(note.id);
        return next;
      });
      return;
    }

    if (!decryptedMap[note.id]) {
      try {
        const content = await decryptContent(note.encrypted_content, currentPin);
        setDecryptedMap((prev) => ({ ...prev, [note.id]: content }));
      } catch {
        setError(t('pinIncorrect'));
        return;
      }
    }
    setVisibleIds((prev) => new Set(prev).add(note.id));
  };

  if (phase === 'enter' && pinSet) {
    return (
      <Modal open onClose={onClose} title={t('secureVault')}>
        <div className="space-y-4">
          <div className="flex flex-col items-center py-4">
            <div className="w-16 h-16 rounded-2xl bg-gray-900 dark:bg-gray-800 flex items-center justify-center mb-4">
              <Lock size={28} className="text-white" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
              {t('enterVaultPin')}
            </p>
          </div>
          <Input
            type="password"
            inputMode="numeric"
            maxLength={4}
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
            placeholder="••••"
            className="text-center text-2xl tracking-widest"
            dir="ltr"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleEnterPin()}
          />
          {error && <p className="text-sm text-red-500 text-center">{error}</p>}
          <Button onClick={handleEnterPin} className="w-full" disabled={pin.length !== 4}>
            {t('unlockVault')}
          </Button>
          <button
            onClick={() => setShowReset(true)}
            className="w-full text-xs text-gray-400 hover:text-red-500 text-center"
          >
            {t('forgotPin')}
          </button>
        </div>

        <ConfirmDialog
          open={showReset}
          onClose={() => setShowReset(false)}
          onConfirm={resetVault}
          title={t('resetVault')}
          message={t('forgotPinMsg')}
          warning={t('resetVaultWarning')}
          confirmText={t('resetVault')}
        />
      </Modal>
    );
  }

  if (phase === 'set' || (!pinSet && phase === 'enter')) {
    return (
      <Modal open onClose={onClose} title={t('secureVault')}>
        <div className="space-y-4">
          <div className="flex flex-col items-center py-2">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center mb-4">
              <Shield size={28} className="text-white" />
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 text-center mb-2">
              {t('createVaultPin')}
            </p>
            <div className="flex items-start gap-2 text-xs text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 rounded-xl px-3 py-2.5">
              <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" />
              <span>{t('vaultPinInfo')}</span>
            </div>
          </div>
          <div>
            <Label>{t('enterPin')}</Label>
            <Input
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
              placeholder="••••"
              className="text-center text-2xl tracking-widest"
              dir="ltr"
              autoFocus
            />
          </div>
          <div>
            <Label>{t('confirmPin')}</Label>
            <Input
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
              placeholder="••••"
              className="text-center text-2xl tracking-widest"
              dir="ltr"
            />
          </div>
          {error && <p className="text-sm text-red-500 text-center">{error}</p>}
          <Button
            onClick={handleSetPin}
            className="w-full"
            disabled={pin.length !== 4 || confirmPin.length !== 4}
          >
            {t('setPin')}
          </Button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal open onClose={onClose} title={t('secureVault')} size="xl">
      <div className="space-y-4">
        <div className="flex items-start gap-2 text-xs text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 rounded-xl px-3 py-2.5">
          <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" />
          <span>{t('vaultWarning')}</span>
        </div>

        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {secureNotes.length} {t('secureNotes')}
          </p>
          <Button
            size="sm"
            onClick={() => {
              setEditingNote(null);
              setShowForm(true);
            }}
            className="gap-1.5"
          >
            <Plus size={16} />
            {t('addSecureNote')}
          </Button>
        </div>

        {secureNotes.length === 0 ? (
          <EmptyState icon={<Shield size={48} />} title={t('noSecureNotes')} />
        ) : (
          <div className="space-y-2">
            {secureNotes.map((note) => (
              <Card key={note.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <Lock size={15} className="text-gray-400 flex-shrink-0" />
                    <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate">
                      {note.title}
                    </h3>
                  </div>
                  <div className="flex items-center gap-0.5 flex-shrink-0">
                    <button
                      onClick={() => toggleVisible(note)}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      {visibleIds.has(note.id) ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                    <button
                      onClick={() => {
                        setEditingNote(note);
                        setShowForm(true);
                      }}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Edit3 size={15} />
                    </button>
                    <button
                      onClick={() => setDeleteTarget(note)}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
                {visibleIds.has(note.id) && decryptedMap[note.id] ? (
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-2 whitespace-pre-wrap">
                    {decryptedMap[note.id]}
                  </p>
                ) : (
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-2 italic">
                    {t('contentHidden')}
                  </p>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>

      {showForm && (
        <VaultNoteForm
          note={editingNote}
          onClose={() => setShowForm(false)}
          onSave={async (title, content) => {
            const currentPin = sessionStorage.getItem(SESSION_KEY);
            if (!currentPin) return;
            const encrypted = await encryptContent(content, currentPin);
            if (editingNote) {
              await update(editingNote.id, {
                title,
                encrypted_content: encrypted,
                content: null,
              });
            } else {
              await create({
                title,
                encrypted_content: encrypted,
                content: null,
                is_secure: true,
              });
            }
            setShowForm(false);
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) await remove(deleteTarget.id);
          setDeleteTarget(null);
        }}
        title={t('delete')}
        message={t('deleteNoteConfirm')}
        confirmText={t('delete')}
      />
    </Modal>
  );
}

function VaultNoteForm({
  note,
  onClose,
  onSave,
}: {
  note: Note | null;
  onClose: () => void;
  onSave: (title: string, content: string) => Promise<void>;
}) {
  const { t } = useApp();
  const [title, setTitle] = useState(note?.title ?? '');
  const [content, setContent] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    setSaveError(null);
    try {
      await onSave(title.trim(), content.trim());
    } catch {
      setSaveError(t('error'));
      setSaving(false);
    }
  };

  return (
    <Modal open onClose={onClose} title={note ? t('editNote') : t('addSecureNote')} size="lg">
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 rounded-xl px-3 py-2.5">
          <KeyRound size={16} className="flex-shrink-0" />
          <span>{t('vaultWarning')}</span>
        </div>
        <div>
          <Label>{t('noteTitle')}</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('title')}
            autoFocus
          />
        </div>
        <div>
          <Label>{t('writeFreely')}</Label>
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('writeFreely')}
            rows={8}
          />
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button onClick={handleSave} disabled={saving || !title.trim()}>
            {t('save')}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
