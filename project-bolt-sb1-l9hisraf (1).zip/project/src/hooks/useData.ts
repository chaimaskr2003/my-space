import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type {
  Challenge,
  ChallengeDay,
  Note,
  Summary,
  Task,
  MindMap,
} from '@/types/database';
import { useAuth } from '@/context/AuthContext';

export function useChallenges() {
  const { user } = useAuth();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('challenges')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setChallenges((data as Challenge[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  const create = async (input: Partial<Challenge>) => {
    const { data, error } = await supabase
      .from('challenges')
      .insert(input)
      .select()
      .maybeSingle();
    if (error) throw error;
    await load();
    return data as Challenge;
  };

  const update = async (id: string, input: Partial<Challenge>) => {
    const { error } = await supabase.from('challenges').update(input).eq('id', id);
    if (error) throw error;
    await load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('challenges').delete().eq('id', id);
    if (error) throw error;
    await load();
  };

  return { challenges, loading, create, update, remove, reload: load };
}

export function useChallengeDays(challengeId: string | null) {
  const { user } = useAuth();
  const [days, setDays] = useState<ChallengeDay[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user || !challengeId) {
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from('challenge_days')
      .select('*')
      .eq('challenge_id', challengeId)
      .order('day_date', { ascending: true });
    setDays((data as ChallengeDay[]) ?? []);
    setLoading(false);
  }, [user, challengeId]);

  useEffect(() => {
    load();
  }, [load]);

  const toggleDay = async (date: string, completed: boolean) => {
    if (!user || !challengeId) return;
    const existing = days.find((d) => d.day_date === date);
    if (existing) {
      const { error } = await supabase
        .from('challenge_days')
        .update({ completed })
        .eq('id', existing.id);
      if (error) throw error;
    } else {
      const { error } = await supabase.from('challenge_days').insert({
        challenge_id: challengeId,
        user_id: user.id,
        day_date: date,
        completed,
      });
      if (error) throw error;
    }
    await load();
  };

  return { days, loading, toggleDay, reload: load };
}

export function useTasks() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', user.id)
      .order('task_date', { ascending: true, nullsFirst: false });
    setTasks((data as Task[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  const create = async (input: Partial<Task>) => {
    const { data, error } = await supabase.from('tasks').insert(input).select().maybeSingle();
    if (error) throw error;
    await load();
    return data as Task;
  };

  const update = async (id: string, input: Partial<Task>) => {
    const { error } = await supabase.from('tasks').update(input).eq('id', id);
    if (error) throw error;
    await load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('tasks').delete().eq('id', id);
    if (error) throw error;
    await load();
  };

  const toggleComplete = async (task: Task) => {
    const completed = !task.completed;
    const { error } = await supabase
      .from('tasks')
      .update({
        completed,
        completed_at: completed ? new Date().toISOString() : null,
      })
      .eq('id', task.id);
    if (error) throw error;
    await load();
  };

  return { tasks, loading, create, update, remove, toggleComplete, reload: load };
}

export function useNotes() {
  const { user } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('notes')
      .select('*')
      .eq('user_id', user.id)
      .order('pinned', { ascending: false })
      .order('updated_at', { ascending: false });
    setNotes((data as Note[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  const create = async (input: Partial<Note>) => {
    const { data, error } = await supabase.from('notes').insert(input).select().maybeSingle();
    if (error) throw error;
    await load();
    return data as Note;
  };

  const update = async (id: string, input: Partial<Note>) => {
    const { error } = await supabase.from('notes').update(input).eq('id', id);
    if (error) throw error;
    await load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('notes').delete().eq('id', id);
    if (error) throw error;
    await load();
  };

  return { notes, loading, create, update, remove, reload: load };
}

export function useSummaries() {
  const { user } = useAuth();
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('summaries')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false });
    setSummaries((data as Summary[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  const create = async (input: Partial<Summary>) => {
    const { data, error } = await supabase
      .from('summaries')
      .insert(input)
      .select()
      .maybeSingle();
    if (error) throw error;
    await load();
    return data as Summary;
  };

  const update = async (id: string, input: Partial<Summary>) => {
    const { error } = await supabase.from('summaries').update(input).eq('id', id);
    if (error) throw error;
    await load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('summaries').delete().eq('id', id);
    if (error) throw error;
    await load();
  };

  return { summaries, loading, create, update, remove, reload: load };
}

export function useMindMaps() {
  const { user } = useAuth();
  const [mindMaps, setMindMaps] = useState<MindMap[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('mindmaps')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false });
    setMindMaps((data as MindMap[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    load();
  }, [load]);

  const create = async (input: Partial<MindMap>) => {
    const { data, error } = await supabase
      .from('mindmaps')
      .insert(input)
      .select()
      .maybeSingle();
    if (error) throw error;
    await load();
    return data as MindMap;
  };

  const update = async (id: string, input: Partial<MindMap>) => {
    const { error } = await supabase.from('mindmaps').update(input).eq('id', id);
    if (error) throw error;
    await load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('mindmaps').delete().eq('id', id);
    if (error) throw error;
    await load();
  };

  return { mindMaps, loading, create, update, remove, reload: load };
}
