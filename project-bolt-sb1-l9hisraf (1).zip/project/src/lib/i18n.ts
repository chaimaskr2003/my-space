export type Language = 'ar' | 'en';

export type TranslationKey =
  | 'appName'
  | 'tagline'
  | 'home'
  | 'challenges'
  | 'tasks'
  | 'notes'
  | 'summaries'
  | 'signIn'
  | 'signUp'
  | 'signOut'
  | 'email'
  | 'password'
  | 'name'
  | 'confirmPassword'
  | 'createAccount'
  | 'haveAccount'
  | 'noAccount'
  | 'welcomeBack'
  | 'createYourAccount'
  | 'today'
  | 'upcoming'
  | 'completed'
  | 'addTask'
  | 'addChallenge'
  | 'addNote'
  | 'addSummary'
  | 'addMindMap'
  | 'title'
  | 'description'
  | 'details'
  | 'date'
  | 'startDate'
  | 'endDate'
  | 'orNumberOfDays'
  | 'numberOfDays'
  | 'save'
  | 'cancel'
  | 'delete'
  | 'edit'
  | 'pause'
  | 'resume'
  | 'search'
  | 'noTasksToday'
  | 'noUpcomingTasks'
  | 'noCompletedTasks'
  | 'noChallenges'
  | 'noNotes'
  | 'noSummaries'
  | 'noMindMaps'
  | 'progress'
  | 'days'
  | 'day'
  | 'completedDays'
  | 'totalDays'
  | 'recentNotes'
  | 'recentSummaries'
  | 'activeChallenges'
  | 'todaysTasks'
  | 'quickAccess'
  | 'aiAssistant'
  | 'askAi'
  | 'aiThinking'
  | 'summarizeNote'
  | 'organizeSummary'
  | 'generateMindMap'
  | 'organizeTasks'
  | 'organizeChallenge'
  | 'secureVault'
  | 'vaultWarning'
  | 'vaultPin'
  | 'setPin'
  | 'enterPin'
  | 'confirmPin'
  | 'vaultLocked'
  | 'unlockVault'
  | 'lockVault'
  | 'vaultNote'
  | 'normalNote'
  | 'pinIncorrect'
  | 'pinSet'
  | 'deleteConfirm'
  | 'deleteChallengeConfirm'
  | 'deleteTaskConfirm'
  | 'deleteNoteConfirm'
  | 'deleteSummaryConfirm'
  | 'deleteMindMapConfirm'
  | 'centralTopic'
  | 'addBranch'
  | 'addSubBranch'
  | 'branches'
  | 'headings'
  | 'bulletPoints'
  | 'addHeading'
  | 'addBullet'
  | 'writeFreely'
  | 'organizeByDate'
  | 'all'
  | 'lightMode'
  | 'darkMode'
  | 'language'
  | 'arabic'
  | 'english'
  | 'settings'
  | 'profile'
  | 'loading'
  | 'error'
  | 'retry'
  | 'saveChanges'
  | 'markComplete'
  | 'markIncomplete'
  | 'reminder'
  | 'reminderTime'
  | 'priority'
  | 'low'
  | 'normal'
  | 'high'
  | 'noDetails'
  | 'addDetails'
  | 'noteTitle'
  | 'summaryTitle'
  | 'mindMapTitle'
  | 'challengeTitle'
  | 'taskTitle'
  | 'selectDate'
  | 'optional'
  | 'required'
  | 'backToHome'
  | 'viewAll'
  | 'create'
  | 'newChallenge'
  | 'newTask'
  | 'newNote'
  | 'newSummary'
  | 'newMindMap'
  | 'editChallenge'
  | 'editTask'
  | 'editNote'
  | 'editSummary'
  | 'editMindMap'
  | 'moveNodes'
  | 'emptyState'
  | 'getStarted'
  | 'daysLeft'
  | 'daysCompleted'
  | 'challengeProgress'
  | 'calendarView'
  | 'moveNodeHint'
  | 'apiKeyMissing'
  | 'aiError'
  | 'aiResult'
  | 'applyResult'
  | 'discard'
  | 'vaultIntro'
  | 'vaultDesc'
  | 'enterVaultPin'
  | 'createVaultPin'
  | 'vaultPinInfo'
  | 'forgotPin'
  | 'forgotPinMsg'
  | 'resetVault'
  | 'resetVaultConfirm'
  | 'resetVaultWarning'
  | 'secureNotes'
  | 'noSecureNotes'
  | 'addSecureNote'
  | 'viewContent'
  | 'hideContent'
  | 'contentHidden'
  | 'showContent'
  | 'pinSetSuccess'
  | 'vaultUnlocked'
  | 'summariesAndMindMaps'
  | 'summariesTab'
  | 'mindMapsTab'
  | 'startDateHelp'
  | 'endDateHelp'
  | 'color'
  | 'pickColor'
  | 'status'
  | 'active'
  | 'paused'
  | 'completedStatus'
  | 'noActiveChallenges'
  | 'homeGreeting'
  | 'goodMorning'
  | 'goodAfternoon'
  | 'goodEvening'
  | 'overview';

const translations: Record<Language, Record<TranslationKey, string>> = {
  ar: {
    appName: 'مساحتي',
    tagline: 'منظمتك الشخصية الخاصة',
    home: 'الرئيسية',
    challenges: 'التحديات',
    tasks: 'المهام',
    notes: 'الملاحظات',
    summaries: 'الملخصات والخرائط',
    signIn: 'تسجيل الدخول',
    signUp: 'إنشاء حساب',
    signOut: 'تسجيل الخروج',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    name: 'الاسم',
    confirmPassword: 'تأكيد كلمة المرور',
    createAccount: 'إنشاء حساب',
    haveAccount: 'لديك حساب بالفعل؟',
    noAccount: 'ليس لديك حساب؟',
    welcomeBack: 'مرحباً بعودتك',
    createYourAccount: 'أنشئ حسابك للبدء',
    today: 'اليوم',
    upcoming: 'قادمة',
    completed: 'مكتملة',
    addTask: 'إضافة مهمة',
    addChallenge: 'إضافة تحدٍ',
    addNote: 'إضافة ملاحظة',
    addSummary: 'إضافة ملخص',
    addMindMap: 'إضافة خريطة ذهنية',
    title: 'العنوان',
    description: 'الوصف',
    details: 'التفاصيل',
    date: 'التاريخ',
    startDate: 'تاريخ البداية',
    endDate: 'تاريخ النهاية',
    orNumberOfDays: 'أو عدد الأيام',
    numberOfDays: 'عدد الأيام',
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تعديل',
    pause: 'إيقاف مؤقت',
    resume: 'استئناف',
    search: 'بحث',
    noTasksToday: 'لا توجد مهام اليوم',
    noUpcomingTasks: 'لا توجد مهام قادمة',
    noCompletedTasks: 'لا توجد مهام مكتملة',
    noChallenges: 'لا توجد تحديات بعد',
    noNotes: 'لا توجد ملاحظات بعد',
    noSummaries: 'لا توجد ملخصات بعد',
    noMindMaps: 'لا توجد خرائط ذهنية بعد',
    progress: 'التقدم',
    days: 'يوم',
    day: 'يوم',
    completedDays: 'أيام مكتملة',
    totalDays: 'إجمالي الأيام',
    recentNotes: 'ملاحظات حديثة',
    recentSummaries: 'ملخصات حديثة',
    activeChallenges: 'التحديات النشطة',
    todaysTasks: 'مهام اليوم',
    quickAccess: 'وصول سريع',
    aiAssistant: 'مساعد الذكاء الاصطناعي',
    askAi: 'اسأل الذكاء الاصطناعي',
    aiThinking: 'يفكر المساعد...',
    summarizeNote: 'لخّص هذه الملاحظة',
    organizeSummary: 'حوّل النص إلى نقاط منظمة',
    generateMindMap: 'أنشئ خريطة ذهنية من النص',
    organizeTasks: 'نظّم المهام حسب الأولوية',
    organizeChallenge: 'ساعدني في تنظيم هذا التحدي',
    secureVault: 'الخزنة الآمنة',
    vaultWarning: 'استخدم الخزنة بمسؤولية. لا تعرض كلمة مرورك لأحد.',
    vaultPin: 'رمز الخزنة',
    setPin: 'تعيين الرمز',
    enterPin: 'أدخل الرمز',
    confirmPin: 'تأكيد الرمز',
    vaultLocked: 'الخزنة مقفلة',
    unlockVault: 'فتح الخزنة',
    lockVault: 'قفل الخزنة',
    vaultNote: 'ملاحظة آمنة',
    normalNote: 'ملاحظة عادية',
    pinIncorrect: 'الرمز غير صحيح',
    pinSet: 'تم تعيين الرمز بنجاح',
    deleteConfirm: 'هل أنت متأكد من الحذف؟',
    deleteChallengeConfirm: 'سيتم حذف هذا التحدي وكل تقدمه.',
    deleteTaskConfirm: 'سيتم حذف هذه المهمة.',
    deleteNoteConfirm: 'سيتم حذف هذه الملاحظة.',
    deleteSummaryConfirm: 'سيتم حذف هذا الملخص.',
    deleteMindMapConfirm: 'سيتم حذف هذه الخريطة الذهنية.',
    centralTopic: 'الموضوع الرئيسي',
    addBranch: 'إضافة فرع',
    addSubBranch: 'إضافة فرع فرعي',
    branches: 'الفروع',
    headings: 'العناوين',
    bulletPoints: 'النقاط',
    addHeading: 'إضافة عنوان',
    addBullet: 'إضافة نقطة',
    writeFreely: 'اكتب بحرية...',
    organizeByDate: 'ترتيب حسب التاريخ',
    all: 'الكل',
    lightMode: 'الوضع الفاتح',
    darkMode: 'الوضع الداكن',
    language: 'اللغة',
    arabic: 'العربية',
    english: 'English',
    settings: 'الإعدادات',
    profile: 'الملف الشخصي',
    loading: 'جارٍ التحميل...',
    error: 'حدث خطأ',
    retry: 'إعادة المحاولة',
    saveChanges: 'حفظ التغييرات',
    markComplete: 'وضع علامة مكتمل',
    markIncomplete: 'إلغاء الإكمال',
    reminder: 'تذكير',
    reminderTime: 'وقت التذكير',
    priority: 'الأولوية',
    low: 'منخفضة',
    normal: 'عادية',
    high: 'عالية',
    noDetails: 'لا توجد تفاصيل',
    addDetails: 'أضف تفاصيل...',
    noteTitle: 'عنوان الملاحظة',
    summaryTitle: 'عنوان الملخص',
    mindMapTitle: 'عنوان الخريطة الذهنية',
    challengeTitle: 'عنوان التحدي',
    taskTitle: 'عنوان المهمة',
    selectDate: 'اختر التاريخ',
    optional: 'اختياري',
    required: 'مطلوب',
    backToHome: 'العودة للرئيسية',
    viewAll: 'عرض الكل',
    create: 'إنشاء',
    newChallenge: 'تحدٍ جديد',
    newTask: 'مهمة جديدة',
    newNote: 'ملاحظة جديدة',
    newSummary: 'ملخص جديد',
    newMindMap: 'خريطة ذهنية جديدة',
    editChallenge: 'تعديل التحدي',
    editTask: 'تعديل المهمة',
    editNote: 'تعديل الملاحظة',
    editSummary: 'تعديل الملخص',
    editMindMap: 'تعديل الخريطة الذهنية',
    moveNodes: 'تحريك العقد',
    emptyState: 'لا يوجد شيء هنا بعد',
    getStarted: 'ابدأ بإضافة عنصر جديد',
    daysLeft: 'أيام متبقية',
    daysCompleted: 'أيام مكتملة',
    challengeProgress: 'تقدم التحدي',
    calendarView: 'عرض التقويم',
    moveNodeHint: 'اسحب العقد لتحريكها',
    apiKeyMissing: 'مفتاح الذكاء الاصطناعي غير مُعد. تطلب الميزة خطة مدفوعة.',
    aiError: 'تعذر الحصول على رد من المساعد. حاول مرة أخرى.',
    aiResult: 'نتيجة المساعد',
    applyResult: 'تطبيق النتيجة',
    discard: 'تجاهل',
    vaultIntro: 'الخزنة الآمنة',
    vaultDesc: 'خزنة مشفرة بمقدار 4 أرقام لحفظ المعلومات الحساسة بأمان.',
    enterVaultPin: 'أدخل رمز الخزنة المكون من 4 أرقام',
    createVaultPin: 'أنشئ رمزاً من 4 أرقام للخزنة',
    vaultPinInfo: 'يُستخدم هذا الرمز لتشفير محتوى الخزنة وفك تشفيره محلياً. لن يُحفظ الرمز على الخادم.',
    forgotPin: 'نسيت الرمز؟',
    forgotPinMsg: 'لا يمكن استرجاع الرمز. يمكنك إعادة تعيين الخزنة لكن سيتم حذف كل المحتوى الآمن.',
    resetVault: 'إعادة تعيين الخزنة',
    resetVaultConfirm: 'سيتم حذف كل الملاحظات الآمنة نهائياً. متابعة؟',
    resetVaultWarning: 'تحذير: هذا الإجراء لا يمكن التراجع عنه',
    secureNotes: 'الملاحظات الآمنة',
    noSecureNotes: 'لا توجد ملاحظات آمنة',
    addSecureNote: 'إضافة ملاحظة آمنة',
    viewContent: 'إظهار المحتوى',
    hideContent: 'إخفاء المحتوى',
    contentHidden: 'المحتوى مشفّر',
    showContent: 'إظهار',
    pinSetSuccess: 'تم تعيين رمز الخزنة',
    vaultUnlocked: 'تم فتح الخزنة',
    summariesAndMindMaps: 'الملخصات والخرائط الذهنية',
    summariesTab: 'الملخصات',
    mindMapsTab: 'الخرائط الذهنية',
    startDateHelp: 'متى يبدأ التحدي؟',
    endDateHelp: 'متى ينتهي؟ أو اتركه فارغاً واستخدم عدد الأيام.',
    color: 'اللون',
    pickColor: 'اختر لوناً',
    status: 'الحالة',
    active: 'نشط',
    paused: 'متوقف مؤقتاً',
    completedStatus: 'مكتمل',
    noActiveChallenges: 'لا توجد تحديات نشطة',
    homeGreeting: 'مرحباً',
    goodMorning: 'صباح الخير',
    goodAfternoon: 'مساء الخير',
    goodEvening: 'مساء الخير',
    overview: 'نظرة عامة',
  },
  en: {
    appName: 'MySpace',
    tagline: 'Your private personal organizer',
    home: 'Home',
    challenges: 'Challenges',
    tasks: 'Tasks',
    notes: 'Notes',
    summaries: 'Summaries',
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    email: 'Email',
    password: 'Password',
    name: 'Name',
    confirmPassword: 'Confirm Password',
    createAccount: 'Create Account',
    haveAccount: 'Already have an account?',
    noAccount: "Don't have an account?",
    welcomeBack: 'Welcome back',
    createYourAccount: 'Create your account to get started',
    today: 'Today',
    upcoming: 'Upcoming',
    completed: 'Completed',
    addTask: 'Add Task',
    addChallenge: 'Add Challenge',
    addNote: 'Add Note',
    addSummary: 'Add Summary',
    addMindMap: 'Add Mind Map',
    title: 'Title',
    description: 'Description',
    details: 'Details',
    date: 'Date',
    startDate: 'Start Date',
    endDate: 'End Date',
    orNumberOfDays: 'Or number of days',
    numberOfDays: 'Number of days',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    pause: 'Pause',
    resume: 'Resume',
    search: 'Search',
    noTasksToday: 'No tasks for today',
    noUpcomingTasks: 'No upcoming tasks',
    noCompletedTasks: 'No completed tasks',
    noChallenges: 'No challenges yet',
    noNotes: 'No notes yet',
    noSummaries: 'No summaries yet',
    noMindMaps: 'No mind maps yet',
    progress: 'Progress',
    days: 'days',
    day: 'day',
    completedDays: 'Completed days',
    totalDays: 'Total days',
    recentNotes: 'Recent notes',
    recentSummaries: 'Recent summaries',
    activeChallenges: 'Active challenges',
    todaysTasks: "Today's tasks",
    quickAccess: 'Quick access',
    aiAssistant: 'AI Assistant',
    askAi: 'Ask AI',
    aiThinking: 'Assistant is thinking...',
    summarizeNote: 'Summarize this note',
    organizeSummary: 'Turn text into organized bullet points',
    generateMindMap: 'Create a mind map from this text',
    organizeTasks: 'Organize tasks by priority',
    organizeChallenge: 'Help me organize this challenge',
    secureVault: 'Secure Vault',
    vaultWarning: 'Use the vault responsibly. Never share your password.',
    vaultPin: 'Vault PIN',
    setPin: 'Set PIN',
    enterPin: 'Enter PIN',
    confirmPin: 'Confirm PIN',
    vaultLocked: 'Vault is locked',
    unlockVault: 'Unlock vault',
    lockVault: 'Lock vault',
    vaultNote: 'Secure note',
    normalNote: 'Normal note',
    pinIncorrect: 'Incorrect PIN',
    pinSet: 'PIN set successfully',
    deleteConfirm: 'Are you sure you want to delete?',
    deleteChallengeConfirm: 'This challenge and all its progress will be deleted.',
    deleteTaskConfirm: 'This task will be deleted.',
    deleteNoteConfirm: 'This note will be deleted.',
    deleteSummaryConfirm: 'This summary will be deleted.',
    deleteMindMapConfirm: 'This mind map will be deleted.',
    centralTopic: 'Central topic',
    addBranch: 'Add branch',
    addSubBranch: 'Add sub-branch',
    branches: 'Branches',
    headings: 'Headings',
    bulletPoints: 'Bullet points',
    addHeading: 'Add heading',
    addBullet: 'Add bullet',
    writeFreely: 'Write freely...',
    organizeByDate: 'Organize by date',
    all: 'All',
    lightMode: 'Light mode',
    darkMode: 'Dark mode',
    language: 'Language',
    arabic: 'العربية',
    english: 'English',
    settings: 'Settings',
    profile: 'Profile',
    loading: 'Loading...',
    error: 'An error occurred',
    retry: 'Retry',
    saveChanges: 'Save changes',
    markComplete: 'Mark complete',
    markIncomplete: 'Mark incomplete',
    reminder: 'Reminder',
    reminderTime: 'Reminder time',
    priority: 'Priority',
    low: 'Low',
    normal: 'Normal',
    high: 'High',
    noDetails: 'No details',
    addDetails: 'Add details...',
    noteTitle: 'Note title',
    summaryTitle: 'Summary title',
    mindMapTitle: 'Mind map title',
    challengeTitle: 'Challenge title',
    taskTitle: 'Task title',
    selectDate: 'Select date',
    optional: 'optional',
    required: 'required',
    backToHome: 'Back to home',
    viewAll: 'View all',
    create: 'Create',
    newChallenge: 'New challenge',
    newTask: 'New task',
    newNote: 'New note',
    newSummary: 'New summary',
    newMindMap: 'New mind map',
    editChallenge: 'Edit challenge',
    editTask: 'Edit task',
    editNote: 'Edit note',
    editSummary: 'Edit summary',
    editMindMap: 'Edit mind map',
    moveNodes: 'Move nodes',
    emptyState: 'Nothing here yet',
    getStarted: 'Get started by adding a new item',
    daysLeft: 'days left',
    daysCompleted: 'days completed',
    challengeProgress: 'Challenge progress',
    calendarView: 'Calendar view',
    moveNodeHint: 'Drag nodes to move them',
    apiKeyMissing: 'AI key not configured. This feature requires a paid plan.',
    aiError: 'Could not get a response from the assistant. Try again.',
    aiResult: 'AI result',
    applyResult: 'Apply result',
    discard: 'Discard',
    vaultIntro: 'Secure Vault',
    vaultDesc: 'An encrypted 4-digit PIN vault to safely store sensitive information.',
    enterVaultPin: 'Enter your 4-digit vault PIN',
    createVaultPin: 'Create a 4-digit PIN for the vault',
    vaultPinInfo: 'This PIN encrypts and decrypts vault content locally. The PIN is never sent to the server.',
    forgotPin: 'Forgot PIN?',
    forgotPinMsg: 'The PIN cannot be recovered. You can reset the vault but all secure content will be deleted.',
    resetVault: 'Reset vault',
    resetVaultConfirm: 'All secure notes will be permanently deleted. Continue?',
    resetVaultWarning: 'Warning: this action cannot be undone',
    secureNotes: 'Secure notes',
    noSecureNotes: 'No secure notes',
    addSecureNote: 'Add secure note',
    viewContent: 'Show content',
    hideContent: 'Hide content',
    contentHidden: 'Content is encrypted',
    showContent: 'Show',
    pinSetSuccess: 'Vault PIN set',
    vaultUnlocked: 'Vault unlocked',
    summariesAndMindMaps: 'Summaries & Mind Maps',
    summariesTab: 'Summaries',
    mindMapsTab: 'Mind Maps',
    startDateHelp: 'When does the challenge start?',
    endDateHelp: 'When does it end? Or leave empty and use number of days.',
    color: 'Color',
    pickColor: 'Pick a color',
    status: 'Status',
    active: 'Active',
    paused: 'Paused',
    completedStatus: 'Completed',
    noActiveChallenges: 'No active challenges',
    homeGreeting: 'Hello',
    goodMorning: 'Good morning',
    goodAfternoon: 'Good afternoon',
    goodEvening: 'Good evening',
    overview: 'Overview',
  },
};

export function getTranslation(lang: Language, key: TranslationKey): string {
  return translations[lang][key] ?? key;
}

export { translations };
