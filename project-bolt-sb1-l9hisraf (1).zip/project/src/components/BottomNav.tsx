import { Home, Trophy, CheckSquare, NotebookPen, Network, Settings as SettingsIcon } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { TranslationKey } from '@/lib/i18n';

export type TabId = 'home' | 'challenges' | 'tasks' | 'notes' | 'summaries' | 'settings';

const navTabs: { id: TabId; icon: typeof Home; labelKey: TranslationKey }[] = [
  { id: 'home', icon: Home, labelKey: 'home' },
  { id: 'challenges', icon: Trophy, labelKey: 'challenges' },
  { id: 'tasks', icon: CheckSquare, labelKey: 'tasks' },
  { id: 'notes', icon: NotebookPen, labelKey: 'notes' },
  { id: 'summaries', icon: Network, labelKey: 'summaries' },
];

export function BottomNav({
  active,
  onChange,
}: {
  active: TabId;
  onChange: (tab: TabId) => void;
}) {
  const { t } = useApp();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-white/90 dark:bg-gray-900/90 backdrop-blur-lg border-t border-gray-200 dark:border-gray-800 safe-bottom">
      <div className="max-w-2xl mx-auto flex items-center justify-around px-2 h-16">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className="relative flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors"
              aria-label={t(tab.labelKey)}
            >
              {isActive && (
                <span className="absolute top-0 h-1 w-8 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 transition-all" />
              )}
              <Icon
                size={22}
                className={`transition-colors ${isActive ? 'text-purple-600 dark:text-purple-400' : 'text-gray-400 dark:text-gray-500'}`}
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span
                className={`text-[10px] font-medium transition-colors ${isActive ? 'text-purple-600 dark:text-purple-400' : 'text-gray-400 dark:text-gray-500'}`}
              >
                {t(tab.labelKey)}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function SettingsButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="p-2 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
      aria-label="Settings"
    >
      <SettingsIcon size={20} />
    </button>
  );
}
