import { useState, type ReactNode } from 'react';
import { AlertTriangle, Loader2, Sparkles, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { supabase } from '@/lib/supabase';

type AiAction =
  | 'summarize_note'
  | 'organize_summary'
  | 'generate_mindmap'
  | 'organize_tasks'
  | 'organize_challenge';

export function AiAssistant({
  action,
  content,
  context,
  onApply,
}: {
  action: AiAction;
  content: string;
  context?: string;
  onApply: (result: string) => void;
}) {
  const { t } = useApp();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const actionLabels: Record<AiAction, string> = {
    summarize_note: t('summarizeNote'),
    organize_summary: t('organizeSummary'),
    generate_mindmap: t('generateMindMap'),
    organize_tasks: t('organizeTasks'),
    organize_challenge: t('organizeChallenge'),
  };

  const runAi = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-assistant`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ action, content, context, token }),
      });

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({}));
        throw new Error(errBody.error || `Request failed (${response.status})`);
      }

      const data = await response.json();
      if (!data.result) throw new Error('Invalid response');
      setResult(data.result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('not configured') || msg.includes('API key')) {
        setError(t('apiKeyMissing'));
      } else {
        setError(t('aiError'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    setOpen(true);
    setResult(null);
    setError(null);
    runAi();
  };

  return (
    <>
      <Button variant="secondary" size="sm" onClick={handleOpen} className="gap-1.5">
        <Sparkles size={16} className="text-purple-600 dark:text-purple-400" />
        {actionLabels[action]}
      </Button>

      <Modal open={open} onClose={() => setOpen(false)} title={t('aiAssistant')} size="lg">
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
            <Sparkles size={16} className="text-purple-500" />
            <span>{actionLabels[action]}</span>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-12">
              <Loader2 size={32} className="animate-spin text-purple-500" />
              <span className="ms-3 text-sm text-gray-500">{t('aiThinking')}</span>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 text-sm text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 rounded-xl px-4 py-3">
              <AlertTriangle size={18} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {result && !loading && (
            <>
              <div className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {t('aiResult')}:
              </div>
              <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 p-4 text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap max-h-80 overflow-y-auto leading-relaxed">
                {result}
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="ghost" onClick={() => setOpen(false)}>
                  {t('discard')}
                </Button>
                <Button
                  onClick={() => {
                    onApply(result);
                    setOpen(false);
                  }}
                >
                  {t('applyResult')}
                </Button>
              </div>
            </>
          )}
        </div>
      </Modal>
    </>
  );
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  warning,
  confirmText,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  warning?: ReactNode;
  confirmText: string;
}) {
  const { t } = useApp();
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm">
      <div className="space-y-4">
        <p className="text-sm text-gray-600 dark:text-gray-400">{message}</p>
        {warning && (
          <div className="flex items-start gap-2 text-sm text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 rounded-xl px-4 py-3">
            <AlertTriangle size={18} className="flex-shrink-0 mt-0.5" />
            <span>{warning}</span>
          </div>
        )}
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button variant="danger" onClick={onConfirm}>
            {confirmText}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
