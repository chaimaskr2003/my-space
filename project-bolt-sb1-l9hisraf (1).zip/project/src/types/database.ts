export type Challenge = {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  start_date: string;
  end_date: string | null;
  duration_days: number | null;
  status: 'active' | 'paused' | 'completed';
  color: string | null;
  created_at: string;
  updated_at: string;
};

export type ChallengeDay = {
  id: string;
  challenge_id: string;
  user_id: string;
  day_date: string;
  completed: boolean;
  created_at: string;
};

export type Task = {
  id: string;
  user_id: string;
  title: string;
  details: string | null;
  task_date: string | null;
  reminder: boolean;
  reminder_time: string | null;
  completed: boolean;
  completed_at: string | null;
  priority: 'low' | 'normal' | 'high';
  created_at: string;
  updated_at: string;
};

export type Note = {
  id: string;
  user_id: string;
  title: string;
  content: string | null;
  is_secure: boolean;
  encrypted_content: string | null;
  pinned: boolean;
  created_at: string;
  updated_at: string;
};

export type Summary = {
  id: string;
  user_id: string;
  title: string;
  content: string | null;
  created_at: string;
  updated_at: string;
};

export type MindMapNode = {
  id: string;
  text: string;
  children: MindMapNode[];
};

export type MindMap = {
  id: string;
  user_id: string;
  title: string;
  data: MindMapNode;
  created_at: string;
  updated_at: string;
};

export type Profile = {
  id: string;
  display_name: string | null;
  created_at: string;
};

export type Settings = {
  id: string;
  user_id: string;
  theme: 'light' | 'dark';
  language: 'ar' | 'en';
  created_at: string;
  updated_at: string;
};
