import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { getTranslation, type Language, type TranslationKey } from '@/lib/i18n';

type Theme = 'light' | 'dark';

type AppContextValue = {
  theme: Theme;
  language: Language;
  setTheme: (t: Theme) => void;
  setLanguage: (l: Language) => void;
  toggleTheme: () => void;
  t: (key: TranslationKey) => string;
  dir: 'rtl' | 'ltr';
};

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>('light');
  const [language, setLanguageState] = useState<Language>('ar');

  useEffect(() => {
    const savedTheme = localStorage.getItem('myspace-theme') as Theme | null;
    const savedLang = localStorage.getItem('myspace-lang') as Language | null;
    if (savedTheme) setThemeState(savedTheme);
    if (savedLang) setLanguageState(savedLang);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('myspace-theme', theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('myspace-lang', language);
  }, [language]);

  const setTheme = (t: Theme) => setThemeState(t);
  const setLanguage = (l: Language) => setLanguageState(l);
  const toggleTheme = () => setThemeState((p) => (p === 'light' ? 'dark' : 'light'));
  const t = (key: TranslationKey) => getTranslation(language, key);
  const dir: 'rtl' | 'ltr' = language === 'ar' ? 'rtl' : 'ltr';

  return (
    <AppContext.Provider
      value={{ theme, language, setTheme, setLanguage, toggleTheme, t, dir }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
